<?php

return [
    'Id'            => 'ID',
    'Type'          => '类型',
    'Params'        => '参数',
    'Command'       => '命令',
    'Content'       => '返回结果',
    'Executetime'   => '执行时间',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Execute again' => '再次执行',
    'Successed'     => '成功',
    'Failured'      => '失败',
    'Status'        => '状态'
];
